package com.g.example.database.query;

import java.util.Date;
import com.alibaba.fastjson.JSON;

public class ExamVOQuery {

    private Integer limit = 1;
    private Integer page = 0;
    private Integer offset = 0;
    private String sort;
    private String order;

    private Integer id;
    private String username;
    private String usernameLike;
    private String password;
    private String passwordLike;
    private Long marks;
    private Boolean sex;
    private Long roleId;

    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getId() {
        return id;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getUsername() {
        return username;
    }
    public void setUsernameLike(String usernameLike) {
        this.usernameLike = usernameLike;
    }
    public String getUsernameLike() {
        return usernameLike;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getPassword() {
        return password;
    }
    public void setPasswordLike(String passwordLike) {
        this.passwordLike = passwordLike;
    }
    public String getPasswordLike() {
        return passwordLike;
    }
    public void setMarks(Long marks) {
        this.marks = marks;
    }
    public Long getMarks() {
        return marks;
    }
    public void setSex(Boolean sex) {
        this.sex = sex;
    }
    public Boolean getSex() {
        return sex;
    }
    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }
    public Long getRoleId() {
        return roleId;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit > 0 ? limit : 1;
        this.offset = this.page * this.limit;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        if (page == null) {
            page = 0;
        }
        this.page = page >= 0 ? page : 0;
        this.offset = this.page * this.limit;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        if (order == null) {
            this.order = null;
            return;
        }
        String t = order.toLowerCase();
        if (!"asc".equals(t) && !"desc".equals(t)) {
            return;
        }
        this.order = order;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
