package com.g.example.database.query;

import java.util.Date;
import com.alibaba.fastjson.JSON;

public class RolesVOQuery {

    private Integer limit = 1;
    private Integer page = 0;
    private Integer offset = 0;
    private String sort;
    private String order;

    private Integer roleId;
    private String roleName;
    private String roleNameLike;
    private Long roleAuths;
    private String roleGroupIds;
    private String roleGroupIdsLike;

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
    public Integer getRoleId() {
        return roleId;
    }
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    public String getRoleName() {
        return roleName;
    }
    public void setRoleNameLike(String roleNameLike) {
        this.roleNameLike = roleNameLike;
    }
    public String getRoleNameLike() {
        return roleNameLike;
    }
    public void setRoleAuths(Long roleAuths) {
        this.roleAuths = roleAuths;
    }
    public Long getRoleAuths() {
        return roleAuths;
    }
    public void setRoleGroupIds(String roleGroupIds) {
        this.roleGroupIds = roleGroupIds;
    }
    public String getRoleGroupIds() {
        return roleGroupIds;
    }
    public void setRoleGroupIdsLike(String roleGroupIdsLike) {
        this.roleGroupIdsLike = roleGroupIdsLike;
    }
    public String getRoleGroupIdsLike() {
        return roleGroupIdsLike;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit > 0 ? limit : 1;
        this.offset = this.page * this.limit;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        if (page == null) {
            page = 0;
        }
        this.page = page >= 0 ? page : 0;
        this.offset = this.page * this.limit;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        if (order == null) {
            this.order = null;
            return;
        }
        String t = order.toLowerCase();
        if (!"asc".equals(t) && !"desc".equals(t)) {
            return;
        }
        this.order = order;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
