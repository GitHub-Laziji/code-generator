package com.g.example.database.dao;

import com.g.example.database.model.ExamVO;
import com.g.example.database.query.ExamVOQuery;

import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface ExamVODao {
    List<ExamVO> select(ExamVOQuery query);
    Integer selectCount(ExamVOQuery query);
    ExamVO selectById(Integer id);
    Integer insert(ExamVO bean);
    Integer update(ExamVO bean);
    Integer delete(Integer id);
}
