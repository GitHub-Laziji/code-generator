package com.g.example.database.dao;

import com.g.example.database.model.RolesVO;
import com.g.example.database.query.RolesVOQuery;

import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface RolesVODao {
    List<RolesVO> select(RolesVOQuery query);
    Integer selectCount(RolesVOQuery query);
    RolesVO selectById(Integer id);
    Integer insert(RolesVO bean);
    Integer update(RolesVO bean);
    Integer delete(Integer id);
}
