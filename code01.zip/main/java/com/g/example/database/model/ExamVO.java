package com.g.example.database.model;

import java.util.Date;
import com.alibaba.fastjson.JSON;

public class ExamVO{

	private Integer id;
	private String username;
	private String password;
	private Long marks;
	private Boolean sex;
	private Long roleId;

	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getId() {
		return id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setMarks(Long marks) {
		this.marks = marks;
	}
	public Long getMarks() {
		return marks;
	}
	public void setSex(Boolean sex) {
		this.sex = sex;
	}
	public Boolean getSex() {
		return sex;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public Long getRoleId() {
		return roleId;
	}

	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
