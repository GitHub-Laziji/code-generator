package com.g.example.database.model;

import java.util.Date;
import com.alibaba.fastjson.JSON;

public class RolesVO{

	private Integer roleId;
	private String roleName;
	private Long roleAuths;
	private String roleGroupIds;

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleAuths(Long roleAuths) {
		this.roleAuths = roleAuths;
	}
	public Long getRoleAuths() {
		return roleAuths;
	}
	public void setRoleGroupIds(String roleGroupIds) {
		this.roleGroupIds = roleGroupIds;
	}
	public String getRoleGroupIds() {
		return roleGroupIds;
	}

	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
